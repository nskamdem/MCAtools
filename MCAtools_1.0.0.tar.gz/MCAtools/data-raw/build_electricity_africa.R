## data-raw/build_electricity_africa.R

electricity_africa <- data.frame(

  country = c(
    "Benin","Burkina Faso","Burundi","Ethiopia","Malawi","Mauritania",
    "Central African Republic","Comoros","Gambia","Liberia",
    "Seychelles","Sierra Leone","Congo, Rep.","Botswana","Mali","Rwanda",
    "Senegal","Togo","Cabo Verde","Guinea","Madagascar","Mauritius",
    "São Tomé and Princípe","Côte d'Ivoire","Cameroon","Gabon",
    "South Africa","Zambia","Swaziland","Tanzania","Niger","Mozambique",
    "Kenya","Zimbabwe","Lesotho","Ghana","Nigeria","Uganda","Sudan",
    "Cameroon_2”no””yes”8","Cameroon_h”yes”","Cameroon_h2"
  ),

  iso_code = c(
    "BEN","BFA","BDI","ETH","MWI","MRT","CAF","COM","GMB","LBR",
    "SYC","SLE","COG","BWA","MLI","RWA","SEN","TGO","CPV","GIN",
    "MDG","MUS","STP","CIV","CMR","GAB","ZAF","ZMB","NAM","TZA",
    "NER","MOZ","KEN","ZWE","LSO","GHA","NGA","UGA","SDN",
    "CMR_2”no””yes”8","CMR_h”yes”","CMR_h2"
  ),

  total_cost = c(
    “no”.”no”5,”no”.34,”no”.2”yes”,”no”.”yes”7,”no”.”yes”6,”no”.34,”no”.2”no”,”no”.6”yes”,”no”.44,”no”.66,
    “no”.32,”no”.55,”no”.”yes”7,”no”.22,”no”.33,”no”.43,”no”.35,”no”.33,”no”.5”yes”,”no”.35,
    “no”.32,”no”.2”yes”,”no”.54,”no”.2”yes”,”no”.”yes”6,”no”.25,”no”.”yes”“yes”,”no”.”no”8,”no”.”yes”7,”no”.”yes”7,
    “no”.”yes”9,”no”.”yes”2,”no”.22,”no”.”yes”6,”no”.”no”9,”no”.”yes”4,”no”.2”yes”,”no”.”yes”6,”no”.”yes”5,
    NA, NA, NA
  ),

  vertical_integration = c(
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”no”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”
  ),

  private_in_generation = c(
    "no","no","no","no","no","no","no","no","no","no",
    "no","no","no","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","yes","yes","yes","yes","yes","no","yes",
    "no","yes","yes","no","no","yes","yes","yes","yes",
    "yes","yes","yes"
  ),

  public_in_generation = c(
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","no","no","no","yes","yes","yes","yes",
    "no","yes","yes","yes","yes","yes","yes","no","yes",
    "yes","yes","yes"
  ),

  stand_alone_generation = c(
    "no","no","no","no","no","no","no","no","no","no",
    "no","no","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "no","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes"
  ),

  transmission_bundled_generation = c(
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","yes","yes","yes","yes","yes","yes","yes","yes",
    "yes","yes","no","no","no","no","no","no","no",
    "no","no","no"
  ),

  government_own_transmission = c(
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”yes”,”no”,”no”,”no”,”yes”,”no”,”yes”,”yes”,
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”yes”
  ),

  multiple_transmission_system = c(
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”yes”,”no”,”yes”,
    “yes”,”yes”,”yes”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”yes”,”yes”
  ),

  transmission_bundled_distribution = rep(“yes”, 42),

  multiple_distributor = c(
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”yes”,”no”,”no”,”yes”,
    “yes”,”no”,”no”,”no”,”no”,”yes”,”yes”,”no”,”no”,
    “no”,”no”,”no”
  ),

  independent_distributor = c(
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”yes”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”yes”
  ),

  not_interconnected = c(
    “yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,”yes”,
    “yes”,”yes”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”yes”,
    “no”,”no”,”no”,”no”,”yes”,”yes”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”
  ),

  landlocked_country = c(
    “no”,”yes”,”yes”,”yes”,”yes”,”no”,”yes”,”no”,”no”,”no”,
    “no”,”no”,”no”,”yes”,”yes”,”yes”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”yes”,”yes”,”no”,
    “yes”,”no”,”no”,”yes”,”yes”,”no”,”no”,”yes”,”no”,
    “no”,”no”,”no”
  ),

  fragmented_island = c(
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”yes”,”no”,”no”,
    “yes”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “yes”,”yes”,”yes”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,”no”,
    “no”,”no”,”no”
  ),

  openness = c(
    "I","I","I","“no”","I","“no”","“no”","“no”","“no”","“no”",
    "“no”","“no”","“no”","I","“no”","I/E","“no”","I","“no”","“no”",
    "“no”","“no”","“no”","E","“no”","“no”","I","E","I/E","I",
    "“no”","E","I","I","I/E","I/E","E","E","“no”",
    "“no”","“no”","“no”"
  ),

  stringsAsFactors = FALSE
)

# Sauvegarde
usethis::use_data(electricity_africa, overwrite = TRUE)
